/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./quick/*.{php,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

