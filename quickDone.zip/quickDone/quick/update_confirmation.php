<?php
if (isset($_POST['Booking_Id'])) {
    $order_id = $_POST['Booking_Id'];

    $conn = mysqli_connect("localhost", "root", "", "quickdone");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape the order_id to prevent SQL injection
    $order_id = mysqli_real_escape_string($conn, $order_id);

    // Update the confirmation status in the database
    $update_query = "UPDATE Booking SET Comfermation_Status ='confirmed' WHERE Booking_Id = '$order_id'";

    $result = mysqli_query($conn, $update_query);

    if ($result) {
        echo "Confirmation status updated successfully";
    } else {
        echo "Error updating confirmation status: " . mysqli_error($conn);
    }

    mysqli_close($conn); // Close the connection
} else {
    echo "Booking ID not provided";
}
